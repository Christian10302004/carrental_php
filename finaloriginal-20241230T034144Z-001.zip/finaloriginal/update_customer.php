<<?php  
// Include the database connection
include 'db.php';

// Validation function for driver's license and other customer inputs
function validateCustomerInput($first_name, $last_name, $phone, $drivers_license)
{
    $errors = [];

    // Check if first name contains only letters
    if (!preg_match("/^[a-zA-Z]+$/", $first_name)) {
        $errors['first_name'] = "First name must contain only letters.";
    }

    // Check if last name contains only letters
    if (!preg_match("/^[a-zA-Z]+$/", $last_name)) {
        $errors['last_name'] = "Last name must contain only letters.";
    }

    // Check phone number format
    if (!preg_match("/^09[0-9]{9}$/", $phone)) {
        $errors['phone'] = "Phone number must be 11 digits long, start with '09', and contain only numbers.";
    }

    // Check driver's license format
    if (!preg_match("/^[A-Z]\d{2} \d{2} \d{6}$/", $drivers_license)) {
        $errors['drivers_license'] = "Driver's license must follow the format LNN NN NNNNNN with uppercase letters and mandatory spaces.";
    }

    return $errors;
}

// Check if the ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure ID is an integer

    // Get current customer details
    $sql = "SELECT * FROM customers WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $customer = $result->fetch_assoc();

    // Check if the customer exists
    if (!$customer) {
        echo "No customer found with that ID.";
        exit();
    }

    // Initialize variables
    $validation_errors = [];

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $drivers_license = $_POST['drivers_license']; // Get the driver's license input

        // Validate input
        $validation_errors = validateCustomerInput($first_name, $last_name, $phone, $drivers_license);

        if (empty($validation_errors)) {
            // Update customer details in the database
            $sql = "UPDATE customers SET first_name=?, last_name=?, email=?, phone=?, address=?, drivers_license=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssi", $first_name, $last_name, $email, $phone, $address, $drivers_license, $id);

            if ($stmt->execute()) {
                echo "Customer updated successfully.";
                header("Location: customers.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        }
    }

} else {
    echo "No ID provided.";
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #333;
            margin-top: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            margin-top: 15px;
            display: inline-block;
        }

        a:hover {
            color: #0056b3;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }
    </style>
</head>
<body>

<h1>Update Customer Information</h1>
<form method="POST" action="update_customer.php?id=<?php echo $id; ?>">
    <label for="drivers_license">Driver's License:</label>
    <input type="text" name="drivers_license" value="<?php echo htmlspecialchars($customer['drivers_license']); ?>" required>
    <?php if (isset($validation_errors['drivers_license'])): ?>
        <p class="error-message"><?php echo $validation_errors['drivers_license']; ?></p>
    <?php endif; ?>

    <label for="first_name">First Name:</label>
    <input type="text" name="first_name" value="<?php echo htmlspecialchars($customer['first_name']); ?>" required>

    <label for="last_name">Last Name:</label>
    <input type="text" name="last_name" value="<?php echo htmlspecialchars($customer['last_name']); ?>" required>

    <label for="email">Email:</label>
    <input type="email" name="email" value="<?php echo htmlspecialchars($customer['email']); ?>" required>

    <label for="phone">Phone:</label>
    <input type="text" name="phone" value="<?php echo htmlspecialchars($customer['phone']); ?>" required>

    <label for="address">Address:</label>
    <textarea name="address" required><?php echo htmlspecialchars($customer['address']); ?></textarea>

    <input type="submit" value="Update Customer">
</form>

<a href="customers.php">Back to Customer List</a>

</body>
</html>
