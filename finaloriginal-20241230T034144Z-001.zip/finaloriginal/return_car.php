<?php
include 'db.php';

// Initialize error messages and success message
$errors = [
    'rental_id' => '',
    'delay' => '',
    'fines' => '',
    'remarks' => '',
];
$success_message = "";
$final_total = 0; // Initialize final total

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form values
    $rental_id = isset($_POST['rental_id']) ? $_POST['rental_id'] : '';
    $delay = isset($_POST['delay']) ? $_POST['delay'] : 0;
    $fines = isset($_POST['fines']) ? $_POST['fines'] : 0.00;
    $remarks = isset($_POST['remarks']) ? $_POST['remarks'] : '';

    $is_valid = true;

    // Validate rental ID
    if (empty($rental_id)) {
        $errors['rental_id'] = "Rental ID is required.";
        $is_valid = false;
    }

    // Validate delay and fines
    if (!is_numeric($delay) || $delay < 0) {
        $errors['delay'] = "Delay must be a valid non-negative number.";
        $is_valid = false;
    }

    if (!is_numeric($fines) || $fines < 0) {
        $errors['fines'] = "Fines must be a valid non-negative number.";
        $is_valid = false;
    }

    if ($is_valid) {
        // Fetch rental details
        $rental_sql = "SELECT r.id AS rental_id, r.return_date, c.id AS car_id, c.price, c.platenumber, r.total_price
                       FROM rentals r
                       JOIN cars c ON r.car_id = c.id
                       WHERE r.id = ? AND c.available = 'NO'";
        $stmt = $conn->prepare($rental_sql);
        $stmt->bind_param("i", $rental_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $rental = $result->fetch_assoc();
        $stmt->close();

        if ($rental) {
            $car_id = $rental['car_id'];
            $return_date = $rental['return_date'];
            $price = $rental['price']; // Use price, not price_per_day
            $total_price = $rental['total_price'];
            $plate_number = $rental['platenumber'];

            // Calculate new return date based on delay
            $new_return_date = date('Y-m-d', strtotime("$return_date +$delay days"));

            // Calculate total cost
            $delay_cost = $delay * $price;
            $final_total = $total_price + $delay_cost + $fines;

            // Insert return details into return_info table, including total
            $insert_return_sql = "INSERT INTO return_info (rental_id, return_date, delay, fines, remarks, total) 
                                  VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insert_return_sql);
            $stmt->bind_param("isidss", $rental_id, $new_return_date, $delay, $fines, $remarks, $final_total);
            $stmt->execute();
            $stmt->close();

            // Update car availability to 'YES'
            $update_car_sql = "UPDATE cars SET available = 'YES' WHERE id = ?";
            $stmt = $conn->prepare($update_car_sql);
            $stmt->bind_param("i", $car_id);
            $stmt->execute();
            $stmt->close();


            $success_message = "Car returned successfully! New return date: $new_return_date. Total cost: $final_total. Plate number: $plate_number.";
        } else {
            $errors['rental_id'] = "Error: Rental not found or car is not rented.";
        }
    }
}

// Fetch rental IDs for dropdown (only show rentals with unavailable cars and not in return_info)
$rental_ids_sql = "SELECT r.id AS rental_id, c.platenumber
                   FROM rentals r
                   JOIN cars c ON r.car_id = c.id
                   LEFT JOIN return_info ri ON r.id = ri.rental_id
                   WHERE c.available = 'NO' AND ri.rental_id IS NULL";
$rental_ids_result = $conn->query($rental_ids_sql);
$rental_ids = [];
if ($rental_ids_result) {
    while ($row = $rental_ids_result->fetch_assoc()) {
        $rental_ids[] = $row;
    }
} else {
    echo "Error fetching rental IDs: " . $conn->error;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Car</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: auto;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .error-message {
            color: red;
            font-size: 0.9em;
        }
        .success-message {
            color: green;
            font-size: 1em;
            margin-bottom: 20px;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
        button {
            padding: 10px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
        }
        button.cancel {
            background-color: #bbb;
        }
        button.submit {
            background-color: #4CAF50;
        }
        #total-box {
            font-weight: bold;
            padding: 10px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1>Return Car</h1>
    <form method="POST" action="">
        <label for="rental_id">Rental ID:</label>
        <select name="rental_id" id="rental_id" required>
            <option value="">Select Rental ID</option>
            <?php foreach ($rental_ids as $rental): ?>
                <option value="<?php echo $rental['rental_id']; ?>" <?php echo (isset($_POST['rental_id']) && $_POST['rental_id'] == $rental['rental_id']) ? 'selected' : ''; ?>>
                    <?php echo $rental['rental_id'] . " - " . $rental['platenumber']; ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php if (!empty($errors['rental_id'])): ?>
            <div class="error-message"><?php echo $errors['rental_id']; ?></div>
        <?php endif; ?>

        <label for="delay">Delay (in days):</label>
        <input type="number" name="delay" id="delay" value="<?php echo htmlspecialchars($_POST['delay'] ?? '0'); ?>" min="0" oninput="calculateTotal()">
        <?php if (!empty($errors['delay'])): ?>
            <div class="error-message"><?php echo $errors['delay']; ?></div>
        <?php endif; ?>

        <label for="fines">Fines:</label>
        <input type="number" name="fines" id="fines" value="<?php echo htmlspecialchars($_POST['fines'] ?? '0.00'); ?>" min="0" step="0.01" oninput="calculateTotal()">
        <?php if (!empty($errors['fines'])): ?>
            <div class="error-message"><?php echo $errors['fines']; ?></div>
        <?php endif; ?>

        <label for="remarks">Remarks:</label>
        <textarea name="remarks" id="remarks"><?php echo htmlspecialchars($_POST['remarks'] ?? ''); ?></textarea>
        <div class="button-container">
            <button type="button" class="cancel" onclick="window.location.href='index.php'">Cancel</button>
            <button type="submit" class="submit">Submit</button>
        </div>

        <?php if (!empty($success_message)): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
    </form>

</body>
</html>
