<?php
// Include the database connection
include 'db.php';

// Validation function
function validateCustomerInput($first_name, $last_name, $phone, $drivers_license)
{
    $errors = [];

    // Check if first name contains only letters
    if (!preg_match("/^[a-zA-Z]+$/", $first_name)) {
        $errors['first_name'] = "First name must contain only letters.";
    }

    // Check if last name contains only letters
    if (!preg_match("/^[a-zA-Z]+$/", $last_name)) {
        $errors['last_name'] = "Last name must contain only letters.";
    }

    // Check phone number format
    if (!preg_match("/^09[0-9]{9}$/", $phone)) {
        $errors['phone'] = "Phone number must be 11 digits long, start with '09', and contain only numbers.";
    }

    // Check driver's license format
    if (!preg_match("/^[A-Z]\d{2} \d{2} \d{6}$/", $drivers_license)) {
        $errors['drivers_license'] = "Driver's license must follow the format LNN NN NNNNNN with uppercase letters and mandatory spaces.";
    }

    return $errors;
}

// Initialize variables
$validation_errors = [];
$success_message = "";
$duplicate_email_error = "";
$duplicate_license_error = "";

// Check if the form is submitted for adding a new customer
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $drivers_license = $_POST['drivers_license'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // Validate input
    $validation_errors = validateCustomerInput($first_name, $last_name, $phone, $drivers_license);

    if (empty($validation_errors)) {
        // Check if drivers_license already exists in the database
        $license_check_query = "SELECT * FROM customers WHERE drivers_license = '$drivers_license'";
        $license_check_result = $conn->query($license_check_query);

        if ($license_check_result->num_rows > 0) {
            // If drivers_license exists, show a duplicate license error
            $duplicate_license_error = "This driver's license is already registered.";
        } else {
            // Check if email already exists in the database
            $email_check_query = "SELECT * FROM customers WHERE email = '$email'";
            $email_check_result = $conn->query($email_check_query);

            if ($email_check_result->num_rows > 0) {
                // If email exists, show a duplicate email error
                $duplicate_email_error = "This email is already registered.";
            } else {
                // If drivers_license and email are unique, insert the customer into the database
                $sql = "INSERT INTO customers (drivers_license, first_name, last_name, email, phone, address) 
                        VALUES ('$drivers_license', '$first_name', '$last_name', '$email', '$phone', '$address')";

                if ($conn->query($sql) === TRUE) {
                    $success_message = "New customer added successfully.";
                    // Clear the form fields
                    $_POST = [];  // Reset $_POST to clear the form
                } else {
                    $validation_errors['general'] = "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        }
    }
}

// Fetch all customers
$result = $conn->query("SELECT * FROM customers");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Customer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            text-align: center;
        }

        .form-container {
            max-width: 500px;
            margin: auto;
            padding: 60px;
            border: 1px solid #ccc;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .error-message {
            color: red;
            font-size: 14px;
        }

        .success-message {
            color: green;
            font-size: 14px;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .button-container a, input[type="submit"] {
            text-decoration: none;
            color: #fff;
            background-color: #007BFF;
            padding: 10px;
            border: none;
            border-radius: 4px;
            text-align: center;
            cursor: pointer;
            flex: 1;
        }

        input[type="submit"] {
            background-color: #28a745;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        .button-container a:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h1>Add a New Customer</h1>

<div class="form-container">
    <form method="POST" action="create_customer.php">
        <label for="drivers_license">Driver's License:</label>
        <input type="text" name="drivers_license" value="<?php echo isset($_POST['drivers_license']) ? htmlspecialchars($_POST['drivers_license']) : ''; ?>">
        <?php if (isset($validation_errors['drivers_license'])): ?>
             <p class="error-message"><?php echo $validation_errors['drivers_license']; ?></p>
         <?php endif; ?>
          <!-- Display duplicate drivers_license error -->
    <?php if (!empty($duplicate_license_error)): ?>
        <p class="error-message"><?php echo $duplicate_license_error; ?></p>
    <?php endif; ?>

        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" value="<?php echo isset($_POST['first_name']) ? htmlspecialchars($_POST['first_name']) : ''; ?>">
        <?php if (isset($validation_errors['first_name'])): ?>
            <p class="error-message"><?php echo $validation_errors['first_name']; ?></p>
        <?php endif; ?>

        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" value="<?php echo isset($_POST['last_name']) ? htmlspecialchars($_POST['last_name']) : ''; ?>">
        <?php if (isset($validation_errors['last_name'])): ?>
            <p class="error-message"><?php echo $validation_errors['last_name']; ?></p>
        <?php endif; ?>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
         <!-- Display duplicate email error -->
    <?php if (!empty($duplicate_email_error)): ?>
        <p class="error-message"><?php echo $duplicate_email_error; ?></p>
    <?php endif; ?>

        <label for="phone">Phone:</label>
        <input type="text" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
        <?php if (isset($validation_errors['phone'])): ?>
            <p class="error-message"><?php echo $validation_errors['phone']; ?></p>
        <?php endif; ?>

        <label for="address">Address:</label>
        <textarea name="address"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>

        <?php if (isset($validation_errors['general'])): ?>
            <p class="error-message"><?php echo $validation_errors['general']; ?></p>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <p class="success-message"><?php echo $success_message; ?></p>
        <?php endif; ?>

        <div class="button-container">
            <a href="index.php">Back</a>
            <input type="submit" value="Add Customer">
        </div>
    </form>
</div>

</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
