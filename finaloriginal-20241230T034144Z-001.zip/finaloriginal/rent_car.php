<?php 
include 'db.php';

$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['customer_id'], $_POST['car_id'], $_POST['rental_date'], $_POST['return_date'], $_POST['rental_duration'])) {
        $customer_id = $_POST['customer_id'];
        $car_id = $_POST['car_id'];
        $rental_date = $_POST['rental_date'];
        $return_date = $_POST['return_date'];
        $rental_duration = $_POST['rental_duration'];

        // Check car availability
        $availability_sql = "SELECT * FROM rentals WHERE car_id = ? AND (return_date IS NULL OR return_date >= ?)";
        $stmt = $conn->prepare($availability_sql);
        $stmt->bind_param("is", $car_id, $rental_date);
        $stmt->execute();
        $availability_result = $stmt->get_result();

        if ($availability_result->num_rows > 0) {
            $success_message = "Sorry, this car is not available for the selected dates.";
        } else {
            // Get car details for pricing
            $car_sql = "SELECT * FROM cars WHERE id = ?";
            $stmt = $conn->prepare($car_sql);
            $stmt->bind_param("i", $car_id);
            $stmt->execute();
            $car_result = $stmt->get_result();
            $car = $car_result->fetch_assoc();

            if ($car) {
                // Get the price per day for the selected car
                $price = $car['price'];  // Ensure this column exists in your 'cars' table
                $total_price = $price * $rental_duration * 1;  // Adding 10% tax

                // Insert rental record
                $rental_sql = "INSERT INTO rentals (customer_id, car_id, rental_date, return_date, rental_duration, total_price) 
                               VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($rental_sql);
                $stmt->bind_param("iissid", $customer_id, $car_id, $rental_date, $return_date, $rental_duration, $total_price);

                if ($stmt->execute()) {
                    // Update car availability to "No" (not available) when rented
                    $update_car_sql = "UPDATE cars SET available = 'NO' WHERE id = ?";
                    $stmt = $conn->prepare($update_car_sql);
                    $stmt->bind_param("i", $car_id);
                    $stmt->execute();

                    $success_message = "Rental recorded successfully! The car is now unavailable.";
                } else {
                    $success_message = "Error: " . $stmt->error;
                }
            } else {
                $success_message = "Error: Car not found.";
            }
        }
    } else {
        $success_message = "Please fill in all required fields.";
    }
}

// Fetch all customers for selection
$customers_sql = "SELECT * FROM customers";
$customers_result = $conn->query($customers_sql);

// Fetch cars that are available for rent (only cars that have not been rented or returned)
$cars_sql = "SELECT * FROM cars WHERE available = 'YES'";  // Fetch only cars that are available
$cars_result = $conn->query($cars_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent a Car</title>
    <script>
        // Ensure rental date cannot go back to a previous date and return date must be after rental date
        function validateDates() {
            const rentalDate = document.getElementById('rental_date');
            const returnDate = document.getElementById('return_date');
            const today = new Date().toISOString().split('T')[0];

            rentalDate.min = today;  // Prevent selecting a date before today
            returnDate.min = rentalDate.value ? rentalDate.value : today;  // Return date must be at least one day after rental date

            if (returnDate.value && returnDate.value <= rentalDate.value) {
                alert("Return date must be after the rental date.");
                returnDate.value = "";
            }
        }

        function calculateDuration() {
            const rentalDate = document.getElementById('rental_date').value;
            const returnDate = document.getElementById('return_date').value;

            if (rentalDate && returnDate) {
                const startDate = new Date(rentalDate);
                const endDate = new Date(returnDate);

                if (endDate > startDate) {
                    const duration = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));
                    document.getElementById('rental_duration').value = duration;
                } else {
                    alert("Return date must be after the rental date.");
                    document.getElementById('rental_duration').value = '';
                }
            }
        }
    </script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
            margin: 30px 0;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        select, input[type="date"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
        .button-container a,
        .button-container input[type="submit"] {
            text-align: center;
            padding: 10px;
            width: 45%;
            border-radius: 4px;
            text-decoration: none;
        }
        .button-container a {
            background-color: #bbb;
            color: white;
            display: inline-block;
        }
        .button-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
        }
        .button-container input[type="submit"]:hover {
            background-color: #45a049;
        }
        .button-container a:hover {
            background-color: #999;
        }
        .success-message {
            margin-top: 20px;
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h1>Rent a Car</h1>

    <form method="POST" action="rent_car.php">
        <label for="customer_id">Select Customer:</label>
        <select name="customer_id" required>
            <?php while ($customer = $customers_result->fetch_assoc()): ?>
                <option value="<?php echo $customer['id']; ?>">
                    <?php echo htmlspecialchars($customer['first_name']) . " " . htmlspecialchars($customer['last_name']); ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <label for="car_id">Select Car:</label>
        <select name="car_id" required>
            <?php while ($car = $cars_result->fetch_assoc()): ?>
                <option value="<?php echo $car['id']; ?>">
                    <?php echo htmlspecialchars($car['platenumber']) . " - " . htmlspecialchars($car['brand']) . " " . htmlspecialchars($car['model']); ?>
                </option>
            <?php endwhile; ?>
        </select><br>

        <label for="rental_date">Rental Date:</label>
        <input type="date" id="rental_date" name="rental_date" onchange="validateDates(); calculateDuration()" required><br>

        <label for="return_date">Return Date:</label>
        <input type="date" id="return_date" name="return_date" onchange="validateDates(); calculateDuration()" required><br>

        <label for="rental_duration">Rental Duration (in days):</label>
        <input type="number" id="rental_duration" name="rental_duration" readonly required><br>

        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="button-container">
            <a href="index.php">Back</a> 
            <input type="submit" value="Rent Car">
        </div>
    </form>

</body>
</html>
