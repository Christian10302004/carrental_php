<?php
// Include the database connection
include 'db.php';

// Check if 'id' is set in the URL query string
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Prepare and execute the delete statement
    $sql = "DELETE FROM cars WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Re-sequence IDs
        $resetSql = "SET @count = 0;
                     UPDATE cars SET id = (@count := @count + 1);
                     ALTER TABLE cars AUTO_INCREMENT = 1;";
        if ($conn->multi_query($resetSql)) {
            // Redirect back to the list of cars after deletion
            header("Location: index.php");
            exit();
        } else {
            echo "Error resetting IDs: " . $conn->error;
        }
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Invalid request.";
}

// Close the database connection
$conn->close();
?>
