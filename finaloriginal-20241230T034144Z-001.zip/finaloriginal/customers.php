<?php
session_start(); // Start the session
include 'db.php'; // Include the database connection

// Check if the connection is established
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete action
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure ID is an integer
    $conn->query("DELETE FROM customers WHERE id = $id");
    header("Location: customers.php"); // Redirect after deletion
    exit();
}

// SQL query to select all customers
$sql = "SELECT * FROM customers";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Customers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        .actions a {
            margin-right: 10px;
            text-decoration: none;
            color: white;
            background-color: #28a745; /* Green color */
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
        }
        .actions a:hover {
            background-color: #218838; /* Darker green on hover */
        }
        .no-customers {
            text-align: center;
            color: #999;
            padding: 20px;
        }
        .home-btn {
            margin: 20px auto;
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: #fff;
            background-color: #4CAF50; /* Green color */
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            text-decoration: none;
        }
        .home-btn:hover {
            background-color: #45a049; /* Darker green on hover */
        }
    </style>
</head>
<body>

    <h1>List of Customers</h1>

    <table>
        <tr>
            <th>ID</th>
            <th>Driver's License</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Actions</th>
        </tr>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['drivers_license']); ?></td>
                    <td><?php echo htmlspecialchars($row['first_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                    <td class="actions">
                        <a href="update_customer.php?id=<?php echo htmlspecialchars($row['id']); ?>">Update</a>
                        <a href="?action=delete&id=<?php echo htmlspecialchars($row['id']); ?>" onclick="return confirm('Are you sure you want to delete this customer?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="8" class="no-customers">No customers found.</td>
            </tr>
        <?php endif; ?>
    </table>

    <div style="margin-bottom: 20px;">
        <button class="home-btn" onclick="window.location.href='index.php'">Return Home</button>
    </div>
</body>
</html>

<?php
$conn->close(); // Close the database connection at the end
?>
