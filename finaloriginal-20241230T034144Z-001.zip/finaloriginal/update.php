<?php
include 'db.php';

// Check if car_id is passed via POST
if (isset($_POST['car_id'])) {
    $car_id = $_POST['car_id'];  // Retrieve the car_id from the POST request

    // Fetch the car details based on car_id
    $sql = "SELECT * FROM cars WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);  // Use the car_id in the prepared statement
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Car found, fetch car details
        $car = $result->fetch_assoc();
    } else {
        echo "Car not found!";
        exit;
    }

    // Handle form submission to update car details
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $platenumber = $_POST['platenumber'];
        $brand = $_POST['brand'];
        $model = $_POST['model'];
        $color = $_POST['color'];
        $price = $_POST['price'];
        $available = isset($_POST['available']) ? 1 : 0;

        // Update car details
        $update_sql = "UPDATE cars SET platenumber = ?, brand = ?, model = ?, color = ?, price = ?, available = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ssssdis", $platenumber, $brand, $model, $color, $price, $available, $car_id);

        if ($stmt->execute()) {
            echo "Car updated successfully!";
        } else {
            echo "Error: " . $stmt->error;
        }
    }
} else {
    echo "No car ID provided!";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Car</title>
</head>
<body>
    <h1>Update Car</h1>
    
    <form method="POST" action="update.php">
        <input type="hidden" name="car_id" value="<?php echo $car['id']; ?>">  <!-- Hidden input to store car_id -->
        
        <label for="platenumber">Registration Number:</label>
        <input type="text" name="platenumber" value="<?php echo htmlspecialchars($car['platenumber']); ?>" required><br><br>

        <label for="brand">Brand:</label>
        <input type="text" name="brand" value="<?php echo htmlspecialchars($car['brand']); ?>" required><br><br>

        <label for="model">Model:</label>
        <input type="text" name="model" value="<?php echo htmlspecialchars($car['model']); ?>" required><br><br>

        <label for="color">Color:</label>
        <input type="text" name="color" value="<?php echo htmlspecialchars($car['color']); ?>" required><br><br>

        <label for="price">Price per day:</label>
        <input type="number" name="price" value="<?php echo htmlspecialchars($car['price']); ?>" required><br><br>

        <label for="available">Available:</label>
        <input type="checkbox" name="available" <?php echo $car['available'] ? 'checked' : ''; ?>><br><br>

        <input type="submit" value="Update Car">
    </form>

</body>
</html>