<?php
// Include the database connection
include 'db.php';

// Fetch all rental records with car details (make, model, registration number)
$sql = "SELECT rentals.*, cars.brand, cars.model, cars.reg_number, customers.first_name, customers.last_name
        FROM rentals
        JOIN cars ON rentals.car_id = cars.id
        JOIN customers ON rentals.customer_id = customers.id
        ORDER BY rentals.rental_date DESC"; // Orders by rental date, most recent first

// Execute the query and check for errors
$result = $conn->query($sql);

if (!$result) {
    // If query fails, display the error and stop execution
    die("Error in query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rental History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:last-child td {
            border-bottom: none;
        }
    </style>
</head>
<body>

    <h1>Rental History</h1>

    <table>
        <tr>
            <th>Customer Name</th>
            <th>Car</th>
            <th>Reg Number</th>
            <th>Rental Date</th>
            <th>Return Date</th>
            <th>Rental Duration (Days)</th>
            <th>Total Price</th>
        </tr>

        <?php
        // Check if there are rental records
        if ($result->num_rows > 0) {
            while ($rental = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($rental['first_name']) . " " . htmlspecialchars($rental['last_name']) . "</td>";
                echo "<td>" . htmlspecialchars($rental['brand']) . " " . htmlspecialchars($rental['model']) . "</td>";
                echo "<td>" . htmlspecialchars($rental['reg_number']) . "</td>";
                echo "<td>" . htmlspecialchars($rental['rental_date']) . "</td>";
                echo "<td>" . ($rental['return_date'] ? htmlspecialchars($rental['return_date']) : 'Not Returned') . "</td>";
                echo "<td>" . htmlspecialchars($rental['rental_duration']) . " days</td>";
                echo "<td>" . number_format($rental['total_price'], 2) . "</td>";
                echo "</tr>";
            }
        } else {
            // No rental records found
            echo "<tr><td colspan='7'>No rental history found.</td></tr>";
        }
        ?>
    </table>

</body>
</html>
