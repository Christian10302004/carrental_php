a<?php
session_start();
session_unset();
session_destroy();

// Set a thank you message
$message = "Thank you for using our service! You will be redirected to the login page shortly.";

// Display the message
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging Out</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            padding: 50px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        p {
            color: green;
        }
    </style>
    <meta http-equiv="refresh" content="2;url=login.php"> <!-- Redirect after 3 seconds -->
</head>
<body>

    <h1>Goodbye!</h1>
    <p><?php echo $message; ?></p>

</body>
</html>
