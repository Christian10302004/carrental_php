<?php 
include 'db.php';

// Initialize error messages and success message
$errors = [
    'platenumber' => '',
    'brand' => '',
    'color' => '',
    'price' => '',
];
$success_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $platenumber = $_POST['platenumber'] ?? '';
    $brand = $_POST['brand'] ?? '';
    $model = $_POST['model'] ?? '';
    $color = $_POST['color'] ?? '';
    $price = $_POST['price_per_day'] ?? '';
    $available = isset($_POST['available']) ? 'YES' : 'NO';  // Store YES/NO in database

    $is_valid = true;

    // Validate registration number format
    if (!preg_match('/^[A-Z]{3}[0-9]{4}$/', $platenumber)) {
        $errors['platenumber'] = "Registration number must be in the format ABC1234.";
        $is_valid = false;
    }

    // Validate brand for letters only
    if (!preg_match('/^[a-zA-Z ]+$/', $brand)) {
        $errors['brand'] = "Brand must contain letters only.";
        $is_valid = false;
    }

    // Validate color for letters only
    if (!preg_match('/^[a-zA-Z ]+$/', $color)) {
        $errors['color'] = "Color must contain letters only.";
        $is_valid = false;
    }

    // Validate price for positive numeric value
    if (!is_numeric($price) || $price <= 0) {
        $errors['price'] = "Price must be a valid positive number.";
        $is_valid = false;
    }

    if ($is_valid) {
        // Check if the registration number already exists
        $check_sql = "SELECT COUNT(*) FROM cars WHERE platenumber = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $platenumber);
        $check_stmt->execute();
        $check_stmt->bind_result($count);
        $check_stmt->fetch();
        $check_stmt->close();

        if ($count > 0) {
            $errors['platenumber'] = "The registration number '$platenumber' already exists.";
        } else {
            // Insert car data into the database
            $sql = "INSERT INTO cars (platenumber, brand, model, color, price, available) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssds", $platenumber, $brand, $model, $color, $price, $available);

            if ($stmt->execute()) {
                $success_message = "Car registered successfully!";
                // Clear form values after successful registration
                $_POST = [];
            } else {
                $success_message = "Error: " . $stmt->error;
            }

            $stmt->close();
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Car</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="text"].error,
        input[type="number"].error {
            border-color: red;
            background-color: #ffe6e6;
        }
        .error-message {
            color: red;
            font-size: 0.9em;
            margin-top: -12px;
            margin-bottom: 10px;
        }
        .success-message {
            color: green;
            font-size: 1em;
            margin-bottom: 20px;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
        .button-container a,
        .button-container input[type="submit"] {
            text-align: center;
            padding: 10px;
            width: 45%;
            border-radius: 4px;
            text-decoration: none;
        }
        .button-container a {
            background-color: #bbb;
            color: white;
            display: inline-block;
        }
        .button-container input[type="submit"] {
            background-color: #4CAF50;
            color: white;
        }
        .button-container input[type="submit"]:hover {
            background-color: #45a049;
        }
        .button-container a:hover {
            background-color: #999;
        }
    </style>
</head>
<body>
    <h1>Register Car</h1>
    <form method="POST" action="">
        

        <label for="platenumber">Plate Number:</label>
        <input type="text" name="platenumber" id="platenumber"  placeholder="Ex. ABC1234"
               value="<?php echo htmlspecialchars($_POST['platenumber'] ?? ''); ?>" 
               class="<?php echo !empty($errors['platenumber']) ? 'error' : ''; ?>" 
               required>
        <?php if (!empty($errors['platenumber'])): ?>
            <div class="error-message"><?php echo $errors['platenumber']; ?></div>
        <?php endif; ?>

        <label for="brand">Brand:</label>
        <input type="text" name="brand" id="brand" placeholder="Ex. TOYOTA"
               value="<?php echo htmlspecialchars($_POST['brand'] ?? ''); ?>" 
               class="<?php echo !empty($errors['brand']) ? 'error' : ''; ?>" 
               required>
        <?php if (!empty($errors['brand'])): ?>
            <div class="error-message"><?php echo $errors['brand']; ?></div>
        <?php endif; ?>

        <label for="model">Model:</label>
        <input type="text" name="model" id="model" placeholder="Ex. PRIUS"
               value="<?php echo htmlspecialchars($_POST['model'] ?? ''); ?>" 
               required>

        <label for="color">Color:</label>
        <input type="text" name="color" id="color" placeholder="Ex. BLACK"
               value="<?php echo htmlspecialchars($_POST['color'] ?? ''); ?>" 
               class="<?php echo !empty($errors['color']) ? 'error' : ''; ?>" 
               required>
        <?php if (!empty($errors['color'])): ?>
            <div class="error-message"><?php echo $errors['color']; ?></div>
        <?php endif; ?>

        <label for="price_per_day">Price Per Day:</label>
        <input type="number" name="price_per_day" id="price_per_day" placeholder="1000"
               step="0.01" 
               value="<?php echo htmlspecialchars($_POST['price_per_day'] ?? ''); ?>" 
               class="<?php echo !empty($errors['price']) ? 'error' : ''; ?>" 
               required>
        <?php if (!empty($errors['price'])): ?>
            <div class="error-message"><?php echo $errors['price']; ?></div>
        <?php endif; ?>

        <label>
            <input type="checkbox" name="available" id="available" 
                   <?php echo isset($_POST['available']) ? 'checked' : ''; ?>>
            Available
        </label>

         <!-- Success Message -->
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>


        <div class="button-container">
            <a href="index.php">Back</a>
            <input type="submit" value="Register">
        </div>
    </form>
</body>
</html>
