<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Cars - Car Rental Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        h2 {
            margin-top: 30px;
            color: #444;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:last-child td {
            border-bottom: none;
        }
        /* Button Styles */
        .button {
            background-color: #4CAF50; /* Green */
            border: none;
            color: white;
            padding: 12px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px 0;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .button:hover {
            background-color: #45a049; /* Darker green */
            transform: scale(1.05); /* Slight zoom effect */
        }

        .button:focus {
            outline: none;
        }

        .action-links a {
            margin: 0 5px;
            color: #007BFF;
            text-decoration: none;
            transition: color 0.3s;
        }
        .action-links a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>View Cars</h1>
    <!-- Display Available Cars -->
    <h2>Available Cars</h2>
    <table>
        <tr>
            <th>Car ID</th>
            <th>Plate Number</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Color</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
        <?php
        // Include the database connection
        include 'db.php';

        // Fetch all available cars
       $available_cars_sql = "SELECT * FROM cars WHERE available = 'YES'";

        $available_cars_result = $conn->query($available_cars_sql);

        if ($available_cars_result->num_rows > 0) {
            while ($row = $available_cars_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['platenumber']) . "</td>";
                echo "<td>" . htmlspecialchars($row['brand']) . "</td>";
                echo "<td>" . htmlspecialchars($row['model']) . "</td>";
                echo "<td>" . htmlspecialchars($row['color']) . "</td>";
                echo "<td>" . number_format($row['price'], 2) . "</td>";
                echo "<td class='action-links'>
                        <a href='update_car.php?id=" . htmlspecialchars($row['id']) . "' class='button'>Update</a>
                        <a href='delete_car.php?id=" . htmlspecialchars($row['id']) . "' class='button' onclick='return confirm(\"Are you sure you want to delete this car?\");'>Delete</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No cars available</td></tr>";
        }

        ?>

    </table>

     <div style="margin-bottom: 20px;">
        <button class="button" onclick="window.location.href='index.php'">Return Home</button>
    </div>
</body>
</html>