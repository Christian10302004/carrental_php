<?php
// Include the database connection
include 'db.php';

// Initialize variables to hold error messages
$error = "";
$success = "";

// Fetch available cars for the dropdown
$cars = [];
$stmt = $conn->prepare("SELECT id, make, model FROM cars WHERE is_deleted = 0");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $cars[] = $row;
}
$stmt->close();

// Check if the form is submitted for adding a new car
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['make'])) {
    // Get the form data and sanitize input
    $make = trim($_POST['make']);
    $model = trim($_POST['model']);
    $price_per_day = trim($_POST['price_per_day']);
    $price_per_month = trim($_POST['price_per_month']);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO cars (make, model, price_per_day, price_per_month) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssii", $make, $model, $price_per_day, $price_per_month);

    // Execute the statement
    if ($stmt->execute()) {
        $success = "New car added successfully.";
    } else {
        $error = "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Car</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px;
            cursor: pointer;
            width: 100%;
        }
        input[type="submit"]:hover {
            background-color: green;
        }
        .message {
            text-align: center;
            margin: 10px 0;
        }
        .message.success {
            color: green;
        }
        .message.error {
            color: red;
        }
        .home-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #007BFF;
            text-decoration: none;
        }
        .home-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <h1>Rent Cars</h1>

    <?php if ($success): ?>
        <p class="message success"><?php echo $success; ?></p>
    <?php endif; ?>

    <?php if ($error): ?>
        <p class="message error"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Form for adding a new car -->
    <form method="POST" action="create.php">
        <label for="make">Make:</label>
        <input type="text" name="make" required>

        <label for="model">Model:</label>
        <input type="text" name="model" required>

        <label for="price_per_day">Price per Day:</label>
        <input type="number" name="price_per_day" required>

        <label for="price_per_month">Price per Month:</label>
        <input type="number" name="price_per_month" required>

        <input type="submit" value="Rent Car">
    </form>

    <a href="index.php" class="home-link">Return to Home</a>

</body>
</html>
