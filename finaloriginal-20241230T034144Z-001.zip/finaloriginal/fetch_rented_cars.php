<?php
include 'db.php';

if (isset($_POST['customer_id'])) {
    $customer_id = $_POST['customer_id'];

    // Fetch the cars rented by the customer
    $cars_sql = "SELECT cars.id, cars.reg_number, cars.brand, cars.model FROM cars 
                 JOIN rentals  ON cars.id = rentals.car_id
                 WHERE rentals.customer_id = ? AND rentals.return_date IS NULL";
    $stmt = $conn->prepare($cars_sql);
    $stmt->bind_param("i", $customer_id);
    $stmt->execute();
    $cars_result = $stmt->get_result();

    if ($cars_result->num_rows > 0) {
        // Display the rented cars for the customer
        while ($car = $cars_result->fetch_assoc()) {
            echo "<label for='car_id'>Select Car to Return:</label><br>";
            echo "<input type='radio' name='car_id' value='" . $car['id'] . "' required>";
            echo " " . htmlspecialchars($car['reg_number']) . " - " . htmlspecialchars($car['brand']) . " " . htmlspecialchars($car['model']) . "<br>";
        }
    } else {
        echo "No active rentals found for this customer.";
    }
} else {
    echo "No customer selected.";
}

$conn->close();
?>
