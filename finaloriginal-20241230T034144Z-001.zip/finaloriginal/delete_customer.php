<?php
// Include the database connection
include 'db.php';

// Check if an ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the customer from the database
    $sql = "DELETE FROM customers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: customers.php"); // Redirect to the customers list
        exit();
    } else {
        echo "Error deleting customer: " . $stmt->error;
    }

    // Close the database connection
    $stmt->close();
    $conn->close();
} else {
    echo "No customer ID provided.";
}
