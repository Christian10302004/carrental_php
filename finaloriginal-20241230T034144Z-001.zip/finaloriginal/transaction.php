<?php
// Include the database connection
include 'db.php';

// Fetch return transaction data including total
$return_sql = "
   SELECT return_info.id AS return_id, rentals.id AS rental_id, cars.platenumber, 
       return_info.return_date, return_info.delay, return_info.fines, 
       return_info.remarks, return_info.total
FROM return_info
LEFT JOIN rentals ON return_info.rental_id = rentals.id
LEFT JOIN cars ON rentals.car_id = cars.id
ORDER BY return_info.return_date DESC";

// Run the query and check for errors
$return_result = $conn->query($return_sql);

if (!$return_result) {
    // Display an error if the query fails
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transactions - Car Rental Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:last-child td {
            border-bottom: none;
        }
        .home-button {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 20px;
            display: inline-block;
        }
        .home-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <h1>Rental Transactions</h1>

    <!-- Rental Transactions Table -->
    <table>
        <tr>
            <th>Rental ID</th>
            <th>Plate Number</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Customer Name</th>
            <th>Rental Date</th>
            <th>Return Date</th>
            <th>Total Price</th>
            <th>Status</th>
        </tr>
        <?php
       $sql = "
       SELECT rentals.id AS rental_id, cars.platenumber, cars.brand, cars.model, 
       customers.first_name, customers.last_name, rentals.rental_date, 
       rentals.return_date, rentals.total_price, 
       CASE 
           WHEN return_info.rental_id IS NOT NULL THEN 'RETURNED' 
           ELSE 'RENTED' 
       END AS status
FROM rentals
JOIN cars ON rentals.car_id = cars.id
JOIN customers ON rentals.customer_id = customers.id
LEFT JOIN return_info ON rentals.id = return_info.rental_id
ORDER BY rentals.rental_date DESC";


        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['rental_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['platenumber']) . "</td>";
                echo "<td>" . htmlspecialchars($row['brand']) . "</td>";
                echo "<td>" . htmlspecialchars($row['model']) . "</td>";
                echo "<td>" . htmlspecialchars($row['first_name'] . ' ' . $row['last_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['rental_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['return_date'] ?: 'Ongoing') . "</td>";
                echo "<td>" . number_format($row['total_price'], 2) . "</td>";
                echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='9'>No rental transactions found</td></tr>";
        }
        ?>
    </table>

    <h1>Return Transactions</h1>

    <!-- Return Transactions Table -->
    <table>
        <tr>
            <th>Return ID</th>
            <th>Rent ID</th>
            <th>Plate Number</th>
            <th>Return Date</th>
            <th>Delay (Days)</th>
            <th>Fines ($)</th>
            <th>Remarks</th>
            <th>Total ($)</th>
        </tr>
        <?php
        // Check if we have results and loop through them
        if ($return_result->num_rows > 0) {
            while ($row = $return_result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['return_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['rental_id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['platenumber']) . "</td>";
                echo "<td>" . htmlspecialchars($row['return_date']) . "</td>";
                echo "<td>" . htmlspecialchars($row['delay']) . "</td>";
                echo "<td>" . number_format($row['fines'], 2) . "</td>";
                echo "<td>" . htmlspecialchars($row['remarks']) . "</td>";
                echo "<td>" . number_format($row['total'], 2) . "</td>"; 
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='8'>No return transactions found</td></tr>";
        }
        ?>
    </table>

    <a href="index.php" class="home-button">Return Home</a>

</body>
</html>
