<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Rental Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        nav {
            margin-bottom: 20px;
            background-color: #333;
            padding: 10px;
            border-radius: 5px;
        }
        nav a {
            color: #fff;
            text-decoration: none;
            margin: 0 15px;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #ffcc00;
        }
        h2 {
            margin-top: 30px;
            color: #444;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 5px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        tr:last-child td {
            border-bottom: none;
        }
    </style>
</head>
<body>

    <h1>Welcome to the Car Rental System</h1>

    <nav>
       
        <a href="register_cars.php">Register Cars</a>
        <a href="view_cars.php">View Cars</a>
        <a href="create_customer.php">Register Customer</a>
        <a href="customers.php">View Customers</a>
        <a href="rent_car.php">Rent a Car</a>
        <a href="return_car.php">Return Car</a> <!-- Added Return Car Link -->
        <a href="transaction.php">Transactions</a> <!-- Added Transactions Link -->
    </nav>

    <h2>All Cars</h2>
    <table>
        <tr>
            <th>Car ID</th>
            <th>Plate Number</th>
            <th>Brand</th>
            <th>Model</th>
            <th>Color</th>
            <th>Price Per Day</th>
            <th>Available</th>
        </tr>
        <?php
// Include the database connection
include 'db.php';

// Fetch all cars
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['platenumber']) . "</td>";
        echo "<td>" . htmlspecialchars($row['brand']) . "</td>";
        echo "<td>" . htmlspecialchars($row['model']) . "</td>";              
        echo "<td>" . htmlspecialchars($row['color']) . "</td>";
        echo "<td>" . number_format($row['price'], 2) . "</td>";
        echo "<td>" . ($row['available'] == 'YES' ? 'YES' : 'NO') . "</td>";  // Corrected availability check
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='7'>No cars available</td></tr>";
}

$conn->close();
?>

    </table>

</body>
</html>