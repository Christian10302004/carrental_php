<?php
// Include database connection
include 'db.php';

// Initialize error messages
$errors = [
    'platenumber' => '',
    'brand' => '',
    'color' => '',
    'price' => '',
];

$success_message = "";

// Check if the 'id' parameter is passed via GET
if (isset($_GET['id'])) {
    $car_id = $_GET['id'];

    // Fetch the car details from the database
    $sql = "SELECT * FROM cars WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $car = $result->fetch_assoc();
    } else {
        echo "Car not found!";
        exit();
    }
} else {
    echo "Car ID is missing!";
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get updated data from the form
    $platenumber = $_POST['platenumber'];
    $brand = $_POST['brand'];
    $model = $_POST['model'];
    $color = $_POST['color'];
    $price = $_POST['price'];

    // Flag to check if the form is valid
    $is_valid = true;

    // Validate registration number format
    if (!preg_match('/^[A-Z]{3}[0-9]{4}$/', $platenumber)) {
        $errors['platenumber'] = "Registration number must be in the format ABC1234.";
        $is_valid = false;
    }

    // Validate brand for letters only
    if (!preg_match('/^[a-zA-Z ]+$/', $brand)) {
        $errors['brand'] = "Brand must contain letters only.";
        $is_valid = false;
    }

    // Validate color for letters only
    if (!preg_match('/^[a-zA-Z ]+$/', $color)) {
        $errors['color'] = "Color must contain letters only.";
        $is_valid = false;
    }

    // Validate price for positive numeric value
    if (!is_numeric($price) || $price <= 0) {
        $errors['price'] = "Price must be a valid positive number.";
        $is_valid = false;
    }

    // If the form is valid, update the car in the database
    if ($is_valid) {
        // Update the car in the database
        $update_sql = "UPDATE cars SET platenumber = ?, brand = ?, model = ?, color = ?, price = ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ssssdi", $platenumber, $brand, $model, $color, $price, $car_id);

        if ($update_stmt->execute()) {
            $success_message = "Car details updated successfully!";
            header("Location: view_cars.php"); // Redirect to view_cars.php after updating
            exit();
        } else {
            echo "Error updating car details.";
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Car - Car Rental Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }
        h1 {
            color: #333;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }
        label {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        input[type="text"], input[type="number"], input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            border: none;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .error-message {
            color: red;
            font-size: 0.9em;
            margin-top: -12px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <h1>Update Car Details</h1>

    <!-- Success Message -->
    <?php if ($success_message): ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <!-- Update Car Form -->
    <form action="update_car.php?id=<?php echo htmlspecialchars($car['id']); ?>" method="POST">
        <label for="platenumber">Registration Number</label>
        <input type="text" id="platenumber" name="platenumber" value="<?php echo htmlspecialchars($car['platenumber']); ?>" required>
        <?php if (!empty($errors['platenumber'])): ?>
            <div class="error-message"><?php echo $errors['platenumber']; ?></div>
        <?php endif; ?>

        <label for="brand">Brand</label>
        <input type="text" id="brand" name="brand" value="<?php echo htmlspecialchars($car['brand']); ?>" required>
        <?php if (!empty($errors['brand'])): ?>
            <div class="error-message"><?php echo $errors['brand']; ?></div>
        <?php endif; ?>

        <label for="model">Model</label>
        <input type="text" id="model" name="model" value="<?php echo htmlspecialchars($car['model']); ?>" required>

        <label for="color">Color</label>
        <input type="text" id="color" name="color" value="<?php echo htmlspecialchars($car['color']); ?>" required>
        <?php if (!empty($errors['color'])): ?>
            <div class="error-message"><?php echo $errors['color']; ?></div>
        <?php endif; ?>

        <label for="price">Price</label>
        <input type="number" id="price" name="price" value="<?php echo htmlspecialchars($car['price']); ?>" required>
        <?php if (!empty($errors['price'])): ?>
            <div class="error-message"><?php echo $errors['price']; ?></div>
        <?php endif; ?>

        <input type="submit" value="Update Car">
    </form>

</body>
</html>
